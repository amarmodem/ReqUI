// Angular
import { Component } from '@angular/core';

@Component({
  selector: 'kt-dropdown5',
  templateUrl: './dropdown5.component.html'
})
export class Dropdown5Component {
}
