import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kt-error6',
  templateUrl: './error6.component.html',
  styleUrls: ['./../../../../../assets/sass/pages/error/error-6.scss']
})
export class Error6Component implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
